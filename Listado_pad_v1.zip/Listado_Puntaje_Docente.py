#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 2024

@author: MMRaggio@gmail.com
"""
import mechanicalsoup
import time
import openpyxl
import re
import json
from openpyxl.styles import Alignment, Border, Side, PatternFill
from datetime import datetime

print("Procesando DPTI")

datos = dict()

# Cargar configuración desde el archivo JSON
with open('config.json', 'r') as f:
    config = json.load(f)

# Crear el navegador y abrir la página
browser = mechanicalsoup.StatefulBrowser()
page = browser.open("http://servicios.abc.gov.ar/servaddo/puntaje.anual.docente/")
time.sleep(1)

# Seleccionar y enviar el formulario usando los datos cargados desde el JSON
browser.select_form()
browser["anio"] = config["anio"]
browser["distrito"] = config["distrito"]
browser["tipo_org"] = config["tipo_org"]
browser["numero"] = config["numero"]
browser.submit_selected()

# Procesar la página
lista = browser.get_current_page().text.splitlines()
lista = list(filter(None, lista))  # Eliminar líneas vacías

# Extraer los datos de la lista
aux = 100
for linea in lista:
    if ') -' in linea:
        aux = 0
    aux += 1
    if aux == 1:
        # Limpiar el nombre eliminando números, paréntesis y lo que está después del guion
        nombre = re.sub(r'\(\d+\)', '', linea).split('-')[0].strip()
    if aux == 2:
        dni = linea.replace('(', '').replace(')', '').strip()
        if not dni[0].isdigit():
            dni = '0' + dni[1:8]
    if aux == 4:
        dni = int(dni)
        puntaje = linea.strip()
        if dni in datos:
            if datos[dni][2] < puntaje:
                datos[dni][2] = puntaje
        else:
            datos[dni] = [nombre, '', puntaje, '']

# Ordenar los datos por puntaje (de mayor a menor)
sorted_data = sorted(datos.items(), key=lambda x: float(x[1][2]), reverse=True)

# Crear archivo Excel
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Puntajes"

# Estilo para encabezado (fondo gris claro y alineación centrada)
header_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
alignment_center = Alignment(horizontal="center", vertical="center")
thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                     top=Side(style='thin'), bottom=Side(style='thin'))

# Crear encabezado en la primera fila con fondo gris claro
headers = ["Nombre", "DNI", "Puntaje", "Si/No", "Firma"]
for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num, value=header)
    cell.fill = header_fill
    cell.alignment = alignment_center
    cell.border = thin_border

# Llenar el Excel con los datos ordenados
for row_num, (dni, info) in enumerate(sorted_data, 2):
    nombre, _, puntaje, _ = info
    ws.cell(row=row_num, column=1, value=nombre).border = thin_border
    ws.cell(row=row_num, column=2, value=dni).alignment = alignment_center  # Centrar DNI
    ws.cell(row=row_num, column=2, value=dni).border = thin_border
    ws.cell(row=row_num, column=3, value=puntaje).alignment = alignment_center  # Centrar Puntaje
    ws.cell(row=row_num, column=3, value=puntaje).border = thin_border
    ws.cell(row=row_num, column=4, value="").border = thin_border  # Columna Si/No vacía
    ws.cell(row=row_num, column=5, value="").border = thin_border  # Columna Firma vacía

# Ajustar manualmente el tamaño de las columnas
ws.column_dimensions['A'].width = 40  # Nombre
ws.column_dimensions['B'].width = 11  # DNI
ws.column_dimensions['C'].width = 8  # Puntaje
ws.column_dimensions['D'].width = 7  # Si/No
ws.column_dimensions['E'].width = 20  # Firma (doble tamaño)

# Guardar el archivo Excel con la fecha actual en el nombre
fecha_actual = datetime.now().strftime("%Y%m%d")
nombre_archivo = f"Listado_Puntaje_Docente_{fecha_actual}.xlsx"
wb.save(nombre_archivo)

print(f"\nArchivo Excel '{nombre_archivo}' generado correctamente.")
