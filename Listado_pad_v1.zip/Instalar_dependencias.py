import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

required_packages = [
    "mechanicalsoup",
    "openpyxl",
    "requests",  # Asegúrate de incluir 'requests' si lo necesitas en el futuro
    "beautifulsoup4",  # Asegúrate de incluir 'beautifulsoup4' si lo necesitas en el futuro
]

for package in required_packages:
    try:
        __import__(package)
    except ImportError:
        print(f"{package} no está instalado. Instalando...")
        install(package)
    else:
        print(f"{package} ya está instalado.")

